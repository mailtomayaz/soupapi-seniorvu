<?php
require_once("DbConnection.php");
class emailDispatcher{
  function emailToprocess($get_array){
	$Dbobj = new DbConnection();
	$conn = $Dbobj->getdbconnect();
	$emailTo = $get_array['emailto'];
	$query = mysqli_query($conn, "SELECT * FROM email_log WHERE emailTo = '" . $emailTo . "'");
	$found = mysqli_num_rows($query);
	if ($found == 0) {
	  $query = "insert into email_log(emailTo, counter, created, modified)VALUES('" . $emailTo . "', 1, now(), now())";
	  $result = mysqli_query($conn, $query);
	  $this->sendEmail($get_array);
	}elseif ($found > 0) {
	  $query = "UPDATE email_log SET counter = counter + 1, modified = now() WHERE emailTo = '" . $emailTo . "'";	
	  $result = mysqli_query($conn, $query);
	  
	  $query = mysqli_query($conn, "SELECT * FROM email_log WHERE emailTo = '" . $emailTo . "' and counter = 6");
	  $found = mysqli_num_rows($query);
	  if ($found > 0) {
	     $this->sendEmail($get_array);
	  }

	}
		
  }
  
  function sendEmail($get_array){
    $_GET = $get_array;
	//date_default_timezone_set('America/New_York');  // Set timezone.
	date_default_timezone_set('America/Chicago');  // Set timezone.
	if(isset($_GET['emailto'])) {
	  $toemailaccount  = $_GET['emailto'];
	  $toemailaccount = filter_var($toemailaccount, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['emailfrom'])) {
	  $fromemailaccount = $_GET['emailfrom'];
	  $fromemailaccount = filter_var($fromemailaccount, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['agentname'])) {
	  $agentname = $_GET['agentname'];
	  $agentname = filter_var($agentname, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['agentemail'])) {
	  $agentemail = $_GET['agentemail'];
	  $agentemail = filter_var($agentemail, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['firstname'])) {
	  $firstname = $_GET['firstname'];
	  $firstname = filter_var($firstname, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['lastname'])) {
	  $lastname = $_GET['lastname'];
	  $lastname = filter_var($lastname, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['leadid'])) {
	  $leadid= $_GET['leadid'];
	}
	if(isset($_GET['template'])) {
	  $template = $_GET['template'];
	  $template = filter_var($template, FILTER_VALIDATE_INT);
	}
	if(isset($_GET['subject'])) {
	  $subject = $_GET['subject'];
	  $subject = filter_var($subject, FILTER_SANITIZE_STRING);
	}
	if(isset($_GET['ani'])) {
	  $ani = $_GET['ani'];
	}
	if(isset($_GET['dnis'])) {
	  $dnis = $_GET['dnis'];
	}
	if(isset($_GET['extension'])) {
	  $pextension = $_GET['extension'];
	}
	if(isset($_GET['atime'])) {
	  $timeappointment = $_GET['atime'];
	  //FORMAT APPOINTMENT TIME
	  $timeappointmenthh = substr($timeappointment,0,2);
	  // TIMEZONE ADJUSTMENT
	  $timeappointmenthh = $timeappointmenthh - 6;  //ADJUST BASED ON TIME OF YEAR
	  $timeappointmentmm = substr($timeappointment,2,2);
	  $timeappointmentnew = "".$timeappointmenthh.":".$timeappointmentmm.":00";
	  $timeappointmentmsg = date('g:i A', strtotime($timeappointmentnew)); 
	}
	if(isset($_GET['adate'])) {
	  $dateappointment = $_GET['adate'];
	  //FORMAT APPOINTMENT DATE
	  $dateappointmentyear = substr($dateappointment,0,4);
	  $dateappointmentmonth = substr($dateappointment,4,2);
	  $dateappointmentday = substr($dateappointment,6,2);
	  $dateappointmentnew = "".$dateappointmentyear."-".$dateappointmentmonth."-".$dateappointmentday."";
	  $dateappointmentmsg = date('l, F j, Y', strtotime($dateappointmentnew)); 
	}
	if(isset($_GET['econsultant'])) {
	  $energyconsultant = $_GET['econsultant'];
	}
	
	ini_set("SMTP", "aspmx.l.google.com");
	ini_set("sendmail_from", $fromemailaccount);
	if ($fromemailaccount == "rpusateri@condadogroup.com") {
	  $agentname = "Rich Pusateri";
	  $bccemail = "jdobrotka@gmail.com";
	  $pextension = 0;
	}
	if ($fromemailaccount == "condado@freedomsolar.com") {
	  $agentname = "Ryan Culver";
	  $pextension = 0;
	}
	if ($fromemailaccount == "support@condadogroup.com") {
	  $agentname = "Condado Group";
	  $pextension = 1;
	}   
	if ($fromemailaccount == "andrew.bove@freedomsolarpower.com") {
	  $agentname = "Andrew Bove";
	  $pextension = 10;
	}
	if ($fromemailaccount == "ethan@freedomsolarpower.com") {
	  $agentname = "Ethan Thomas";
	  $pextension = 3;
	}
	if ($fromemailaccount == "jessica@freedomsolarpower.com") {
	  $agentname = "Jessica Ramirez";
	  $pextension = 9;
	}
	if ($fromemailaccount == "lisset@freedomsolarpower.com") {
	  $agentname = "Lisset Kanak";
	  $pextension = 8;
	}
	if ($fromemailaccount == "bret@freedomsolarpower.com") {
	  $agentname = "Bret Biggart";
	  $pextension = 5;
	}
	if ($fromemailaccount == "kyle@freedomsolarpower.com") {
	  $agentname = "Kyle Frazier";
	  $pextension = 6;
	}
	if ($fromemailaccount == "niko@freedomsolarpower.com") {
	  $agentname = "Niko Druzhinin";
	  $pextension = 13;
	}
	if ($fromemailaccount == "zach@freedomsolarpower.com") {
	  $agentname = "Zach Stirling";
	  $pextension = 2;
	}   
	if ($energyconsultant == "Stirling,Zach") {
	  $energyconsultantname = "Zach Stirling";
	  //$energyconsultantemail = "zach@freedomsolarpower.com";
	  $energyconsultantemail = "rpusateri@tilpro.com";
	  $ecextension = 99;
	}   
	switch ($template) {
	  case 1:
		$subject = "Follow-Up";
		$message = file_get_contents("templates/template-1.html");
		$search = array('{firstname}', '{agentname}', '{pextension}', '{fromemailaccount}');
		$replace = array($firstname, $agentname, $pextension, $fromemailaccount);
		$message = str_replace($search, $replace, $message);
	   break;
	   case 2:
		 $subject = "Solar Consultation Confirmation";
		 $message = file_get_contents("templates/template-2.html");
		 $search = array('{firstname}', '{energyconsultantname}', '{dateappointmentmsg}', '{timeappointmentmsg}', '{agentname}', '{pextension}', '{fromemailaccount}', '{energyconsultantname}', '{ecextension}', '{energyconsultantemail}');
		 $replace = array($firstname, $energyconsultantname, $dateappointmentmsg, $timeappointmentmsg, $agentname, $pextension, $fromemailaccount, $energyconsultantname, $ecextension, $energyconsultantemail);
		 $message = str_replace($search, $replace, $message);
	   break;
	   default:
		 $subject = "Follow-Up";
		 $message = file_get_contents("templates/default.html");
		 $search = array('{firstname}', '{agentname}', '{pextension}', '{fromemailaccount}');
		 $replace = array($firstname, $agentname, $pextension, $fromemailaccount);
		 $message = str_replace($search, $replace, $message);
	   break;
	}
	//echo $message;
	//exit(); 
	// To send HTML mail, the Content-type header must be set
	//$myheader[] = 'MIME-Version: 1.0';
	//$myheader[] = 'Content-type: text/html; charset=iso-8859-1';
	
	// Additional headers
	//$myheader[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
	//$myheader[] = 'From: Birthday Reminder <birthday@example.com>';
	//$myheader[] = 'Cc: birthdayarchive@example.com';
	//$myheader[] = 'Bcc: birthdaycheck@example.com';
	 
	$headers = "From: ".$agentname." <".$fromemailaccount.">" . "\r\n";
	$headers .= "Cc: ".$energyconsultantemail."\r\n";
	$headers .= "Bcc: ".$bccemail."\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
	if (mail($toemailaccount, $subject, $message, $headers)) {
	  echo 'Your email has been sent successfully.';
	} 
	else {
	  echo 'Unable to send email. Please try again.';
	}
  }
  

}
?>