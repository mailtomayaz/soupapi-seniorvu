<?php
class DbConnection{
  function getdbconnect(){
    $username = "root";
    $password = "";
    $hostname = "localhost"; 
    $database= "email_tracking";
    //connection to the database
    $conn = mysqli_connect($hostname, $username, $password, $database) or die("Could not select examples");
	return $conn;
  }
}
?>