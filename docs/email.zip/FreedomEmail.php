<?php
require_once("classes/emailDispatcher.php");
$Emailobj = new emailDispatcher(); 
$Emailobj->emailToprocess($_GET);
 
?>